
CRM Intelligence Dashboard v3

FEATURES
- Upload Excel files
- Read all monthly sheets automatically
- Global Filters
- Period Filter
- Province Filter
- AE Filter
- HOT/WARM/COOL/COLD
- Opportunity Score
- Buyer Health
- Province Intelligence
- AE Dashboard
- Demand Dashboard
- Feedback Dashboard
- AI Recommendation

HOW TO RUN

1. Install Python
2. Open terminal
3. Run:

pip install -r requirements.txt

4. Run app:

streamlit run app.py
