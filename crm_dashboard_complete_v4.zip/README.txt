CRM Intelligence Dashboard v4

Updates included:
1. Formula display fixed using st.code so + and - signs do not break as markdown bullets.
2. Health Score updated:
   - Login % = Total Login latest 6 months / 30
   - Sold Avg./Month = Total Sold latest 6 months / 6
   - Health Score = Login Score x 50% + Sold Score x 50%
3. Opportunity Score updated:
   - Opportunity Score = Bid Score x 50% + Buyer Size Score x 30% + Coverage Gap Score x 20%
   - Demand Log removed from Opportunity Score.
4. Global filters affect dashboard calculations.
5. Multi-page app with 10 dashboard sections.
6. Each graph has business explanation under the title without using the word Purpose.

Files required in GitHub:
- app.py
- requirements.txt

Streamlit main file path:
app.py
