
CRM Interactive Dashboard

HOW TO RUN

1. Install Python
2. Open Terminal

3. Install packages:
pip install -r requirements.txt

4. Run app:
streamlit run app.py

5. Browser will open automatically

FEATURES
- Upload Excel files
- Interactive Filters
- Auto KPI
- Opportunity Score
- AE Dashboard
- Province Dashboard
- Buyer Health
- Demand Dashboard
- Feedback Dashboard
